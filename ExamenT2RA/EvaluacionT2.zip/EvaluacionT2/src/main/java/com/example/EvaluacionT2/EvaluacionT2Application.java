package com.example.EvaluacionT2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluacionT2Application {

	public static void main(String[] args) {
		SpringApplication.run(EvaluacionT2Application.class, args);
	}

}
