package com.example.EvaluacionT2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluacionT2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
